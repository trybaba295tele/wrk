import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from app.config import settings
from app.database import AsyncSessionLocal
from app.engine import DealDetectionEngine
from app.notifier import notifier
from app.scrapers import AmazonScraper, FlipkartScraper, MyntraScraper

logger = logging.getLogger("deal_finder.scheduler")


class DealFinderScheduler:
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.engine = DealDetectionEngine()
        self.is_scanning = False
        self.last_scan_time: Optional[datetime] = None
        self.scrapers = {
            "amazon": AmazonScraper(),
            "flipkart": FlipkartScraper(),
            "myntra": MyntraScraper(),
        }

    async def run_deal_discovery_job(self) -> Dict[str, Any]:
        """
        Execute full scraping and deal evaluation across all configured sites and categories.
        """
        if self.is_scanning:
            logger.warning("Scan job already in progress. Skipping concurrent run.")
            return {"status": "skipped", "message": "Job already running"}

        self.is_scanning = True
        start_time = datetime.now(timezone.utc)
        logger.info(f"Starting scheduled deal discovery at {start_time.isoformat()}")

        total_scraped = 0
        total_deals_found = 0
        alerts_dispatched = 0

        try:
            for site_key, site_scraper in self.scrapers.items():
                categories = settings.categories.get(site_key, [])
                if not categories:
                    logger.info(f"No configured categories for {site_key}. Skipping.")
                    continue

                for target in categories:
                    logger.info(f"Scraping {site_scraper.name} -> {target.name} ({target.url})")
                    try:
                        items = await site_scraper.scrape_category(target.url, target.category)
                        total_scraped += len(items)

                        # Process items in database
                        async with AsyncSessionLocal() as session:
                            for item in items:
                                product, is_new_deal = await self.engine.process_and_save_item(session, item)
                                if product.is_deal:
                                    total_deals_found += 1

                                # Check Telegram notification condition
                                if (
                                    is_new_deal
                                    and product.confidence_score >= settings.thresholds.min_confidence_for_telegram
                                ):
                                    sent = await notifier.send_deal_alert(session, product)
                                    if sent:
                                        alerts_dispatched += 1

                    except Exception as cat_err:
                        logger.error(f"Error scraping {site_key} category '{target.name}': {cat_err}", exc_info=True)

            self.last_scan_time = datetime.now(timezone.utc)
            duration = (self.last_scan_time - start_time).total_seconds()
            logger.info(
                f"Completed deal discovery in {duration:.1f}s. Scraped: {total_scraped}, Deals: {total_deals_found}, Alerts: {alerts_dispatched}"
            )
            return {
                "status": "success",
                "scraped_count": total_scraped,
                "deals_count": total_deals_found,
                "alerts_sent": alerts_dispatched,
                "duration_sec": duration,
            }
        except Exception as e:
            logger.error(f"Fatal error during deal discovery run: {e}", exc_info=True)
            return {"status": "error", "message": str(e)}
        finally:
            self.is_scanning = False

    def start(self) -> None:
        """Start APScheduler background job loop."""
        interval = settings.scheduler.interval_minutes
        self.scheduler.add_job(
            self.run_deal_discovery_job,
            trigger=IntervalTrigger(minutes=interval),
            id="deal_discovery_task",
            name="Periodic Deal & MRP Error Scanner",
            replace_existing=True,
        )
        self.scheduler.start()
        logger.info(f"APScheduler initiated. Scanning scheduled every {interval} minutes.")

        # Optional kick off on startup in background task
        if settings.scheduler.run_on_startup:
            asyncio.create_task(self.run_deal_discovery_job())

    def shutdown(self) -> None:
        """Shutdown APScheduler."""
        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("APScheduler stopped.")


deal_scheduler = DealFinderScheduler()
