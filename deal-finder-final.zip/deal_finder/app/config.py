import os
import yaml
from pathlib import Path
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from dotenv import load_dotenv

# Load .env file
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.yaml"


class CategoryTarget(BaseModel):
    name: str
    url: str
    category: str


class AppConfig(BaseModel):
    name: str = "Deal Finder Pro"
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    database_url: str = "sqlite+aiosqlite:///./deals.db"


class SchedulerConfig(BaseModel):
    interval_minutes: int = 30
    run_on_startup: bool = True


class ThresholdsConfig(BaseModel):
    min_heavy_discount_pct: float = 70.0
    mrp_error_drop_from_avg_pct: float = 80.0
    min_seller_rating: float = 3.0
    min_reviews: int = 5
    min_confidence_for_telegram: float = 75.0


class AffiliateConfig(BaseModel):
    amazon_tag: str = "dealfinder-21"
    flipkart_tag: str = "dealfinder"
    myntra_tag: str = "dealfinder"


class ScraperConfig(BaseModel):
    min_delay_sec: float = 2.0
    max_delay_sec: float = 5.0
    max_retries: int = 3
    timeout_sec: int = 30
    use_playwright_fallback: bool = True
    headless: bool = True


class TelegramConfig(BaseModel):
    bot_token: Optional[str] = None
    chat_id: Optional[str] = None
    enabled: bool = False


class Settings(BaseModel):
    app: AppConfig = Field(default_factory=AppConfig)
    scheduler: SchedulerConfig = Field(default_factory=SchedulerConfig)
    thresholds: ThresholdsConfig = Field(default_factory=ThresholdsConfig)
    affiliate: AffiliateConfig = Field(default_factory=AffiliateConfig)
    scraper: ScraperConfig = Field(default_factory=ScraperConfig)
    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    categories: Dict[str, List[CategoryTarget]] = Field(default_factory=dict)

    @classmethod
    def load(cls) -> "Settings":
        raw_data = {}
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                raw_data = yaml.safe_load(f) or {}

        # Environment variable overrides
        tg_token = os.getenv("TELEGRAM_BOT_TOKEN")
        tg_chat = os.getenv("TELEGRAM_CHAT_ID")
        tg_enabled = os.getenv("TELEGRAM_ALERTS_ENABLED", "").lower() in ("true", "1", "yes")

        db_url = os.getenv("DATABASE_URL")
        app_port = os.getenv("APP_PORT")

        amazon_tag = os.getenv("AMAZON_PARTNER_TAG")
        flipkart_tag = os.getenv("FLIPKART_AFFILIATE_ID")

        if "app" not in raw_data:
            raw_data["app"] = {}
        if db_url:
            raw_data["app"]["database_url"] = db_url
        if app_port:
            try:
                raw_data["app"]["port"] = int(app_port)
            except ValueError:
                pass

        if "affiliate" not in raw_data:
            raw_data["affiliate"] = {}
        if amazon_tag:
            raw_data["affiliate"]["amazon_tag"] = amazon_tag
        if flipkart_tag:
            raw_data["affiliate"]["flipkart_tag"] = flipkart_tag

        raw_data["telegram"] = {
            "bot_token": tg_token if tg_token else raw_data.get("telegram", {}).get("bot_token"),
            "chat_id": tg_chat if tg_chat else raw_data.get("telegram", {}).get("chat_id"),
            "enabled": tg_enabled if tg_token and tg_chat else False,
        }

        return cls(**raw_data)


settings = Settings.load()
