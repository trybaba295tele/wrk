import logging
from datetime import datetime, timedelta, timezone
from typing import Optional
import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Product, DealAlert
from app.config import settings

logger = logging.getLogger("deal_finder.notifier")


class TelegramNotifier:
    def __init__(self):
        self.config = settings.telegram
        self.bot_token = self.config.bot_token
        self.chat_id = self.config.chat_id
        self.enabled = bool(self.config.enabled and self.bot_token and self.chat_id)

    def is_configured(self) -> bool:
        return self.enabled

    async def should_send_alert(self, session: AsyncSession, product: Product) -> bool:
        """Prevent alert fatigue: check if alerted in the last 6 hours."""
        six_hours_ago = datetime.now(timezone.utc) - timedelta(hours=6)
        stmt = (
            select(DealAlert)
            .where(DealAlert.product_id == product.id)
            .where(DealAlert.sent_at >= six_hours_ago)
            .order_by(DealAlert.sent_at.desc())
        )
        res = await session.execute(stmt)
        recent_alert = res.scalars().first()

        if not recent_alert:
            return True

        # Send again only if price dropped even lower than previous alert
        if product.current_price < recent_alert.price_at_alert:
            return True

        return False

    async def send_deal_alert(self, session: AsyncSession, product: Product) -> bool:
        """
        Format and send deal notification to Telegram.
        """
        if not self.is_configured():
            logger.debug("Telegram alerts disabled or not configured.")
            return False

        if not await self.should_send_alert(session, product):
            logger.info(f"Skipping Telegram alert for '{product.title[:30]}' (recently alerted).")
            return False

        badge = "🚨 *MRP PRICING ERROR*" if "MRP" in (product.deal_type or "") else "🔥 *HEAVY DISCOUNT DEAL*"
        site_name = product.site.upper()

        text = (
            f"{badge}\n\n"
            f"🛒 *Store:* {site_name}\n"
            f"📦 *Item:* {product.title[:120]}\n\n"
            f"💰 *Deal Price:* ₹{product.current_price:,.0f}\n"
            f"🏷️ *MRP:* ~₹{product.mrp:,.0f}~\n"
            f"⚡ *Discount:* {product.discount_percent:.0f}% OFF\n"
            f"🎯 *Confidence Score:* {product.confidence_score:.0f}/100\n"
            f"🔍 *Reason:* {product.deal_reason or 'Great discount'}\n"
            f"⭐ *Rating:* {product.rating or 'N/A'}★ ({product.review_count or 0} reviews)\n\n"
            f"👉 [GET THIS DEAL NOW]({product.affiliate_url or product.product_url})"
        )

        api_url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            "chat_id": self.chat_id,
            "text": text,
            "parse_mode": "Markdown",
            "disable_web_page_preview": False,
        }

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(api_url, json=payload)
                if resp.status_code == 200:
                    logger.info(f"Telegram alert sent for product ID {product.id} ({product.title[:30]})")
                    # Log alert in DB
                    alert = DealAlert(
                        product_id=product.id,
                        channel="TELEGRAM",
                        price_at_alert=product.current_price,
                        discount_at_alert=product.discount_percent,
                        confidence_score=product.confidence_score,
                    )
                    session.add(alert)
                    await session.commit()
                    return True
                else:
                    logger.error(f"Telegram API error {resp.status_code}: {resp.text}")
        except Exception as e:
            logger.error(f"Failed to dispatch Telegram message: {e}")

        return False


notifier = TelegramNotifier()
