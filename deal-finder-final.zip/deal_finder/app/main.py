import logging
import asyncio
from datetime import datetime, timezone, timedelta
from typing import Optional, List
from fastapi import FastAPI, Depends, Query, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy import select, func, desc, asc
from sqlalchemy.ext.asyncio import AsyncSession
from contextlib import asynccontextmanager

from app.config import settings, BASE_DIR
from app.database import init_db, get_db, AsyncSessionLocal
from app.models import Product, PriceHistory
from app.schemas import (
    DealListResponse,
    DealItem,
    PriceHistoryItem,
    ProductDetailResponse,
    StatsResponse,
    ScanTriggerResponse,
)
from app.scheduler import deal_scheduler

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("deal_finder.main")


async def seed_initial_demo_deals_if_empty():
    """
    Seed initial high-value deals with historical price data if the database is empty.
    Ensures that the dashboard is immediately interactive and visual on first launch.
    """
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(func.count(Product.id)))
        count = result.scalar()
        if count and count > 0:
            return

        logger.info("Initializing database with initial verified deal samples...")
        now = datetime.now(timezone.utc)

        sample_products = [
            {
                "site": "amazon",
                "external_id": "B0B9123XYZ",
                "title": "Sony WH-1000XM5 Wireless Noise Cancelling Headphones",
                "product_url": "https://www.amazon.in/dp/B0B9123XYZ",
                "affiliate_url": f"https://www.amazon.in/dp/B0B9123XYZ?tag={settings.affiliate.amazon_tag}",
                "image_url": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80",
                "current_price": 5999.0,
                "mrp": 34990.0,
                "discount_percent": 82.8,
                "rating": 4.6,
                "review_count": 4820,
                "seller": "Appario Retail Pvt Ltd",
                "in_stock": True,
                "category": "Electronics",
                "is_deal": True,
                "deal_type": "COMBO_MRP_GLITCH",
                "confidence_score": 96.0,
                "deal_reason": "MRP Glitch: 80% below 30d avg; Heavy Discount 83% off; Verified Seller (4.6★)",
                "history": [31990.0, 29990.0, 29990.0, 5999.0],
            },
            {
                "site": "flipkart",
                "external_id": "MOBGQ7FZ8299K",
                "title": "Apple iPhone 15 (Blue, 128 GB) - A16 Bionic & 48MP Camera",
                "product_url": "https://www.flipkart.com/apple-iphone-15-blue-128-gb/p/itmd01e92",
                "affiliate_url": f"https://www.flipkart.com/apple-iphone-15-blue-128-gb/p/itmd01e92?affid={settings.affiliate.flipkart_tag}",
                "image_url": "https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?w=500&q=80",
                "current_price": 19999.0,
                "mrp": 79900.0,
                "discount_percent": 75.0,
                "rating": 4.7,
                "review_count": 12850,
                "seller": "SuperComNet (Assured)",
                "in_stock": True,
                "category": "Mobiles",
                "is_deal": True,
                "deal_type": "COMBO_MRP_GLITCH",
                "confidence_score": 94.0,
                "deal_reason": "Potential Pricing Error: 75% off flagship device; Flipkart Assured; 12k+ reviews",
                "history": [71999.0, 69999.0, 68999.0, 19999.0],
            },
            {
                "site": "myntra",
                "external_id": "18942031",
                "title": "Puma Men Pure Velocity Running Shoes",
                "product_url": "https://www.myntra.com/shoes/puma/pure-velocity/18942031/buy",
                "affiliate_url": f"https://www.myntra.com/shoes/puma/pure-velocity/18942031/buy?utm_source=affiliate&utm_medium={settings.affiliate.myntra_tag}",
                "image_url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80",
                "current_price": 999.0,
                "mrp": 4999.0,
                "discount_percent": 80.0,
                "rating": 4.3,
                "review_count": 890,
                "seller": "Puma Official Store",
                "in_stock": True,
                "category": "Footwear",
                "is_deal": True,
                "deal_type": "HEAVY_DISCOUNT",
                "confidence_score": 88.0,
                "deal_reason": "Heavy Discount: 80% off MRP; Official Brand Store; Strong Rating (4.3★)",
                "history": [3499.0, 2999.0, 2499.0, 999.0],
            },
            {
                "site": "amazon",
                "external_id": "B09WXYZ111",
                "title": "Instant Pot Duo 7-in-1 Electric Pressure Cooker 5.7L",
                "product_url": "https://www.amazon.in/dp/B09WXYZ111",
                "affiliate_url": f"https://www.amazon.in/dp/B09WXYZ111?tag={settings.affiliate.amazon_tag}",
                "image_url": "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=500&q=80",
                "current_price": 1499.0,
                "mrp": 9999.0,
                "discount_percent": 85.0,
                "rating": 4.5,
                "review_count": 3120,
                "seller": "Cloudtail Retail",
                "in_stock": True,
                "category": "Home & Kitchen",
                "is_deal": True,
                "deal_type": "MRP_ERROR",
                "confidence_score": 92.5,
                "deal_reason": "MRP Glitch: 85% drop; 30-day baseline ₹7,999; High ratings count",
                "history": [8499.0, 7999.0, 7999.0, 1499.0],
            },
            {
                "site": "flipkart",
                "external_id": "WATGR20239",
                "title": "Fossil Gen 6 Smartwatch with AMOLED Display & Wear OS",
                "product_url": "https://www.flipkart.com/fossil-gen-6-smartwatch/p/itmwat982",
                "affiliate_url": f"https://www.flipkart.com/fossil-gen-6-smartwatch/p/itmwat982?affid={settings.affiliate.flipkart_tag}",
                "image_url": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80",
                "current_price": 4499.0,
                "mrp": 24995.0,
                "discount_percent": 82.0,
                "rating": 4.1,
                "review_count": 640,
                "seller": "Flashstar Commerce",
                "in_stock": True,
                "category": "Electronics",
                "is_deal": True,
                "deal_type": "HEAVY_DISCOUNT",
                "confidence_score": 86.0,
                "deal_reason": "Heavy Discount: 82% off MRP; Verified Assured Seller",
                "history": [21995.0, 18995.0, 17999.0, 4499.0],
            },
        ]

        for p_data in sample_products:
            hist = p_data.pop("history")
            prod = Product(**p_data)
            session.add(prod)
            await session.flush()

            # Add simulated 30-day price history
            for idx, price_point in enumerate(hist):
                point_date = now - timedelta(days=(len(hist) - idx) * 7)
                pct = ((prod.mrp - price_point) / prod.mrp) * 100.0
                session.add(
                    PriceHistory(
                        product_id=prod.id,
                        price=price_point,
                        mrp=prod.mrp,
                        discount_percent=round(pct, 2),
                        timestamp=point_date,
                    )
                )

        await session.commit()
        logger.info("Demo deals seeded successfully.")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting up Deal Finder Pro...")
    await init_db()
    await seed_initial_demo_deals_if_empty()
    deal_scheduler.start()
    yield
    # Shutdown
    logger.info("Shutting down Deal Finder Pro...")
    deal_scheduler.shutdown()


app = FastAPI(
    title=settings.app.name,
    description="Real-time E-Commerce Deal & MRP Pricing Error Finder",
    version="1.0.0",
    lifespan=lifespan,
)

# Mount static assets
static_path = BASE_DIR / "app" / "static"
app.mount("/static", StaticFiles(directory=str(static_path)), name="static")


@app.get("/", include_in_schema=False)
async def serve_dashboard():
    """Serve the single-page application dashboard."""
    index_file = static_path / "index.html"
    return FileResponse(str(index_file))


@app.get("/api/deals", response_model=DealListResponse)
async def get_deals(
    site: Optional[str] = Query(None, description="Filter by site: amazon, flipkart, myntra"),
    category: Optional[str] = Query(None, description="Filter by category"),
    deal_type: Optional[str] = Query(None, description="Filter: HEAVY_DISCOUNT, MRP_ERROR, COMBO_MRP_GLITCH"),
    min_discount: Optional[float] = Query(None, ge=0, le=100),
    min_price: Optional[float] = Query(None, ge=0),
    max_price: Optional[float] = Query(None, ge=0),
    sort_by: str = Query("confidence", pattern="^(confidence|discount|price_asc|price_desc|recent)$"),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """
    List filtered and sorted deals.
    """
    query = select(Product).where(Product.is_deal == True).where(Product.in_stock == True)

    if site and site.lower() != "all":
        query = query.where(Product.site == site.lower())

    if category and category.lower() != "all":
        query = query.where(Product.category == category)

    if deal_type and deal_type.lower() != "all":
        if deal_type == "MRP_ERROR":
            query = query.where(Product.deal_type.in_(["MRP_ERROR", "COMBO_MRP_GLITCH"]))
        elif deal_type == "HEAVY_DISCOUNT":
            query = query.where(Product.deal_type.in_(["HEAVY_DISCOUNT", "COMBO_MRP_GLITCH"]))
        else:
            query = query.where(Product.deal_type == deal_type)

    if min_discount is not None:
        query = query.where(Product.discount_percent >= min_discount)

    if min_price is not None:
        query = query.where(Product.current_price >= min_price)

    if max_price is not None:
        query = query.where(Product.current_price <= max_price)

    # Sorting
    if sort_by == "confidence":
        query = query.order_by(desc(Product.confidence_score), desc(Product.discount_percent))
    elif sort_by == "discount":
        query = query.order_by(desc(Product.discount_percent), desc(Product.confidence_score))
    elif sort_by == "price_asc":
        query = query.order_by(asc(Product.current_price))
    elif sort_by == "price_desc":
        query = query.order_by(desc(Product.current_price))
    elif sort_by == "recent":
        query = query.order_by(desc(Product.updated_at))

    # Total count query
    count_stmt = select(func.count()).select_from(query.subquery())
    total_count = (await db.execute(count_stmt)).scalar() or 0

    # Paginate
    paged_stmt = query.offset(offset).limit(limit)
    res = await db.execute(paged_stmt)
    products = res.scalars().all()

    return DealListResponse(
        total=total_count,
        deals=[DealItem.model_validate(p) for p in products],
    )


@app.get("/api/products/{product_id}/history", response_model=List[PriceHistoryItem])
async def get_product_price_history(
    product_id: int,
    db: AsyncSession = Depends(get_db),
):
    """
    Fetch chronological price history points for mini chart visualization.
    """
    stmt = (
        select(PriceHistory)
        .where(PriceHistory.product_id == product_id)
        .order_by(asc(PriceHistory.timestamp))
    )
    result = await db.execute(stmt)
    records = result.scalars().all()
    return [PriceHistoryItem.model_validate(r) for r in records]


@app.get("/api/stats", response_model=StatsResponse)
async def get_system_stats(
    db: AsyncSession = Depends(get_db),
):
    """
    Returns high-level statistics for the dashboard banner.
    """
    total_prod = (await db.execute(select(func.count(Product.id)))).scalar() or 0
    active_deals = (
        await db.execute(select(func.count(Product.id)).where(Product.is_deal == True))
    ).scalar() or 0
    mrp_errors = (
        await db.execute(
            select(func.count(Product.id))
            .where(Product.is_deal == True)
            .where(Product.deal_type.in_(["MRP_ERROR", "COMBO_MRP_GLITCH"]))
        )
    ).scalar() or 0
    heavy_discounts = (
        await db.execute(
            select(func.count(Product.id))
            .where(Product.is_deal == True)
            .where(Product.deal_type == "HEAVY_DISCOUNT")
        )
    ).scalar() or 0

    return StatsResponse(
        total_products_tracked=total_prod,
        active_deals_count=active_deals,
        mrp_errors_count=mrp_errors,
        heavy_discounts_count=heavy_discounts,
        last_scan_time=deal_scheduler.last_scan_time,
        scheduler_running=deal_scheduler.scheduler.running,
    )


@app.post("/api/scan/trigger", response_model=ScanTriggerResponse)
async def trigger_manual_scan(background_tasks: BackgroundTasks):
    """
    Manually trigger an asynchronous deal discovery crawl.
    """
    if deal_scheduler.is_scanning:
        return ScanTriggerResponse(
            status="busy",
            message="A scraping task is already running in background.",
        )

    background_tasks.add_task(deal_scheduler.run_deal_discovery_job)
    return ScanTriggerResponse(
        status="triggered",
        message="Deal discovery scan has been initiated in background.",
    )
