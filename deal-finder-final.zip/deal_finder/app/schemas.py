from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, HttpUrl, Field


class ScrapedProductItem(BaseModel):
    site: str
    external_id: Optional[str] = None
    title: str
    product_url: str
    image_url: Optional[str] = None
    current_price: float
    mrp: float
    discount_percent: float = 0.0
    rating: Optional[float] = 0.0
    review_count: Optional[int] = 0
    seller: Optional[str] = "Unknown"
    in_stock: bool = True
    category: Optional[str] = "General"
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PriceHistoryItem(BaseModel):
    id: int
    price: float
    mrp: float
    discount_percent: float
    timestamp: datetime

    class Config:
        from_attributes = True


class DealItem(BaseModel):
    id: int
    site: str
    external_id: Optional[str] = None
    title: str
    product_url: str
    affiliate_url: Optional[str] = None
    image_url: Optional[str] = None
    current_price: float
    mrp: float
    discount_percent: float
    rating: Optional[float] = 0.0
    review_count: Optional[int] = 0
    seller: Optional[str] = None
    in_stock: bool
    category: Optional[str] = None
    is_deal: bool
    deal_type: Optional[str] = None
    confidence_score: float
    deal_reason: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class DealListResponse(BaseModel):
    total: int
    deals: List[DealItem]


class ProductDetailResponse(DealItem):
    price_history: List[PriceHistoryItem] = []


class StatsResponse(BaseModel):
    total_products_tracked: int
    active_deals_count: int
    mrp_errors_count: int
    heavy_discounts_count: int
    last_scan_time: Optional[datetime] = None
    scheduler_running: bool


class ScanTriggerResponse(BaseModel):
    status: str
    message: str
    triggered_at: datetime = Field(default_factory=datetime.utcnow)
