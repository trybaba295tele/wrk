import logging
from datetime import datetime, timedelta, timezone
from typing import Tuple, List, Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Product, PriceHistory, DealAlert
from app.schemas import ScrapedProductItem
from app.config import settings
from app.scrapers.utils import build_affiliate_url

logger = logging.getLogger("deal_finder.engine")


class DealDetectionEngine:
    def __init__(self):
        self.thresholds = settings.thresholds
        self.affiliate = settings.affiliate

    async def get_30_day_average_price(self, session: AsyncSession, product_id: int) -> Optional[float]:
        """Calculate average price for a product over the last 30 days."""
        thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
        stmt = (
            select(func.avg(PriceHistory.price))
            .where(PriceHistory.product_id == product_id)
            .where(PriceHistory.timestamp >= thirty_days_ago)
        )
        result = await session.execute(stmt)
        avg = result.scalar()
        return float(avg) if avg else None

    async def get_category_avg_mrp(self, session: AsyncSession, category: str, site: str) -> Optional[float]:
        """Compute average MRP in a category to detect inflated MRP anomalies."""
        if not category:
            return None
        stmt = (
            select(func.avg(Product.mrp))
            .where(Product.category == category)
            .where(Product.site == site)
        )
        result = await session.execute(stmt)
        avg = result.scalar()
        return float(avg) if avg else None

    def evaluate_deal(
        self,
        item: ScrapedProductItem,
        avg_30d_price: Optional[float],
        category_avg_mrp: Optional[float] = None,
    ) -> Tuple[bool, Optional[str], float, str]:
        """
        Evaluate if a scraped item is a Heavy Discount, MRP Error, or regular product.
        Returns: (is_deal, deal_type, confidence_score, deal_reason)
        """
        # 1. Filter out disqualified items immediately
        if not item.in_stock:
            return False, None, 0.0, "Disqualified: Out of stock"

        if (item.review_count or 0) < self.thresholds.min_reviews:
            return False, None, 0.0, f"Disqualified: Fewer than {self.thresholds.min_reviews} reviews"

        if item.rating and item.rating < self.thresholds.min_seller_rating:
            return False, None, 0.0, f"Disqualified: Rating ({item.rating}★) below minimum {self.thresholds.min_seller_rating}★"

        reasons: List[str] = []
        is_heavy_discount = False
        is_mrp_error = False
        confidence = 0.0

        # 2. Check Heavy Discount (>= 70%)
        if item.discount_percent >= self.thresholds.min_heavy_discount_pct:
            is_heavy_discount = True
            reasons.append(f"Heavy Discount: {item.discount_percent:.0f}% off MRP")
            # Base confidence proportional to discount
            confidence += min(45.0, (item.discount_percent - 50.0) * 1.5)

        # 3. Check MRP Error
        # Condition A: price is at least 80% below the product's own 30-day average
        if avg_30d_price and avg_30d_price > 0:
            price_drop_from_avg = ((avg_30d_price - item.current_price) / avg_30d_price) * 100.0
            if price_drop_from_avg >= self.thresholds.mrp_error_drop_from_avg_pct:
                is_mrp_error = True
                confidence += 40.0
                reasons.append(
                    f"MRP Glitch: {price_drop_from_avg:.0f}% drop below 30d avg (₹{item.current_price:.0f} vs ₹{avg_30d_price:.0f})"
                )

        # Condition B: Extreme discount (> 85%) or anomalous MRP vs category
        if item.discount_percent >= 85.0:
            is_mrp_error = True
            confidence += 20.0
            reasons.append(f"Potential pricing error: extreme {item.discount_percent:.0f}% cut")

        if category_avg_mrp and category_avg_mrp > 0:
            if item.mrp > (category_avg_mrp * 3.5) and item.discount_percent >= 80.0:
                confidence += 10.0
                reasons.append("Inflated MRP detected vs category peers")

        # Not a qualified deal if neither heavy discount nor MRP error
        if not (is_heavy_discount or is_mrp_error):
            return False, None, 0.0, "Normal price range"

        # 4. Reputation & credibility adjustments
        if (item.rating or 0) >= 4.0:
            confidence += 10.0
            reasons.append(f"Strong rating: {item.rating}★")
        elif (item.rating or 0) >= 3.5:
            confidence += 5.0

        if (item.review_count or 0) >= 100:
            confidence += 10.0
            reasons.append(f"High review count: {item.review_count} reviews")
        elif (item.review_count or 0) >= 20:
            confidence += 5.0

        # Cap confidence at 99.0
        final_confidence = min(99.0, max(15.0, round(confidence, 1)))

        # Determine deal type
        if is_heavy_discount and is_mrp_error:
            deal_type = "COMBO_MRP_GLITCH"
        elif is_mrp_error:
            deal_type = "MRP_ERROR"
        else:
            deal_type = "HEAVY_DISCOUNT"

        summary_reason = "; ".join(reasons)
        return True, deal_type, final_confidence, summary_reason

    async def process_and_save_item(
        self,
        session: AsyncSession,
        item: ScrapedProductItem,
    ) -> Tuple[Product, bool]:
        """
        Upsert product in database, record price history, evaluate deal rules,
        and update affiliate links.
        Returns: (Product, is_new_top_deal)
        """
        # Check if product already exists
        stmt = select(Product).where(Product.product_url == item.product_url)
        res = await session.execute(stmt)
        product = res.scalar_one_or_none()

        affiliate_url = build_affiliate_url(item.product_url, item.site, self.affiliate)

        if not product:
            product = Product(
                site=item.site,
                external_id=item.external_id,
                title=item.title,
                product_url=item.product_url,
                affiliate_url=affiliate_url,
                image_url=item.image_url,
                current_price=item.current_price,
                mrp=item.mrp,
                discount_percent=item.discount_percent,
                rating=item.rating,
                review_count=item.review_count,
                seller=item.seller,
                in_stock=item.in_stock,
                category=item.category,
                is_deal=False,
                confidence_score=0.0,
            )
            session.add(product)
            await session.flush()
        else:
            product.current_price = item.current_price
            product.mrp = item.mrp
            product.discount_percent = item.discount_percent
            product.rating = item.rating
            product.review_count = item.review_count
            product.seller = item.seller
            product.in_stock = item.in_stock
            product.category = item.category or product.category
            product.affiliate_url = affiliate_url
            if item.image_url:
                product.image_url = item.image_url

        # Record price history point
        history_entry = PriceHistory(
            product_id=product.id,
            price=item.current_price,
            mrp=item.mrp,
            discount_percent=item.discount_percent,
        )
        session.add(history_entry)
        await session.flush()

        # Retrieve 30-day average price & category baseline
        avg_30d = await self.get_30_day_average_price(session, product.id)
        cat_avg = await self.get_category_avg_mrp(session, product.category, product.site)

        # Run deal detection evaluation
        is_deal, deal_type, confidence, reason = self.evaluate_deal(
            item, avg_30d_price=avg_30d, category_avg_mrp=cat_avg
        )

        was_deal = product.is_deal
        product.is_deal = is_deal
        product.deal_type = deal_type
        product.confidence_score = confidence
        product.deal_reason = reason

        await session.commit()
        await session.refresh(product)

        # Determine if this warrants a fresh notification
        is_new_alert_deal = is_deal and (
            not was_deal or confidence >= self.thresholds.min_confidence_for_telegram
        )

        return product, is_new_alert_deal
