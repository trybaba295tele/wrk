from .base import BaseScraper
from .amazon import AmazonScraper
from .flipkart import FlipkartScraper
from .myntra import MyntraScraper

__all__ = ["BaseScraper", "AmazonScraper", "FlipkartScraper", "MyntraScraper"]
