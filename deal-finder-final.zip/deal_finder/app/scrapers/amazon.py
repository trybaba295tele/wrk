import os
import re
import logging
from typing import List, Optional
from bs4 import BeautifulSoup
from urllib.parse import urljoin

from app.scrapers.base import BaseScraper
from app.schemas import ScrapedProductItem
from app.scrapers.utils import (
    fetch_html_with_retry,
    clean_price,
    clean_number,
    random_delay,
)

logger = logging.getLogger("deal_finder.scrapers.amazon")


class AmazonScraper(BaseScraper):
    site_id = "amazon"
    name = "Amazon India"
    base_url = "https://www.amazon.in"

    def __init__(self):
        super().__init__()
        self.access_key = os.getenv("AMAZON_ACCESS_KEY")
        self.secret_key = os.getenv("AMAZON_SECRET_KEY")
        self.partner_tag = os.getenv("AMAZON_PARTNER_TAG", "dealfinder-21")

    def _extract_asin(self, url: str) -> Optional[str]:
        match = re.search(r"/(?:dp|gp/product|d)/([A-Z0-9]{10})", url)
        return match.group(1) if match else None

    async def scrape_category(self, url: str, category_name: str) -> List[ScrapedProductItem]:
        """
        Scrape deals from category or search result pages.
        """
        logger.info(f"[{self.name}] Scraping category '{category_name}' from: {url}")
        items: List[ScrapedProductItem] = []

        html = await fetch_html_with_retry(
            url,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout_sec,
            referer="https://www.amazon.in/",
        )

        if not html:
            # Try headless browser fallback
            html = await self.render_with_playwright(
                url,
                wait_selector='div[data-component-type="s-search-result"], div[data-testid="grid-deals-container"]',
            )

        if not html:
            logger.warning(f"[{self.name}] Could not retrieve page content for: {url}")
            return items

        soup = BeautifulSoup(html, "html.parser")

        # 1. Standard search result containers
        product_cards = soup.select('div[data-component-type="s-search-result"]')

        # 2. Today's Deals / Goldbox widgets fallback
        if not product_cards:
            product_cards = soup.select('div[data-testid="deal-card"], div.a-section.octopus-pc-item')

        for card in product_cards:
            try:
                asin = card.get("data-asin")
                # Title & URL
                title_elem = card.select_one("h2 a, a.a-link-normal span.a-text-normal, span.octopus-pc-item-title")
                link_elem = card.select_one("h2 a, a.a-link-normal[href*='/dp/'], a.a-link-normal[href*='/gp/product/']")

                if not title_elem or not link_elem:
                    continue

                title = title_elem.get_text(strip=True)
                raw_href = link_elem.get("href", "")
                if not raw_href:
                    continue

                full_url = urljoin(self.base_url, raw_href.split("?")[0])
                if not asin:
                    asin = self._extract_asin(full_url)

                # Current Price
                price = None
                price_elem = card.select_one(
                    "span.a-price span.a-offscreen, span.a-price-whole, span.octopus-pc-item-price"
                )
                if price_elem:
                    price = clean_price(price_elem.get_text())

                # MRP / Original Price (crossed out)
                mrp = None
                mrp_elem = card.select_one(
                    "span.a-price.a-text-price span.a-offscreen, span.a-text-strike, span.octopus-pc-item-strike-price"
                )
                if mrp_elem:
                    mrp = clean_price(mrp_elem.get_text())

                # If no separate MRP element, check if price exists and fallback to price
                if not price:
                    continue
                if not mrp or mrp < price:
                    mrp = price

                discount = self.compute_discount(price, mrp)

                # Rating
                rating = 0.0
                rating_elem = card.select_one("i.a-icon-star-small span.a-icon-alt, span[aria-label*='out of 5 stars']")
                if rating_elem:
                    match_rating = re.search(r"(\d+(?:\.\d+)?)", rating_elem.get_text())
                    if match_rating:
                        rating = float(match_rating.group(1))

                # Review count
                reviews = 0
                review_elem = card.select_one(
                    "span.s-underline-text, a[href*='#customerReviews'] span, span.a-size-small.a-color-secondary"
                )
                if review_elem:
                    reviews = clean_number(review_elem.get_text())

                # Image
                image_url = None
                img_elem = card.select_one("img.s-image, img.octopus-pc-item-image")
                if img_elem:
                    image_url = img_elem.get("src")

                # In stock check
                stock_text = card.get_text().lower()
                in_stock = "currently unavailable" not in stock_text

                items.append(
                    ScrapedProductItem(
                        site=self.site_id,
                        external_id=asin,
                        title=title[:450],
                        product_url=full_url,
                        image_url=image_url,
                        current_price=price,
                        mrp=mrp,
                        discount_percent=discount,
                        rating=rating,
                        review_count=reviews,
                        seller="Amazon Seller",
                        in_stock=in_stock,
                        category=category_name,
                    )
                )
            except Exception as item_err:
                logger.debug(f"Error parsing Amazon product item: {item_err}")
                continue

        logger.info(f"[{self.name}] Extracted {len(items)} items from '{category_name}'")
        await random_delay(self.config.min_delay_sec, self.config.max_delay_sec)
        return items

    async def fetch_product(self, url: str) -> Optional[ScrapedProductItem]:
        """
        Fetch single product page details.
        """
        html = await fetch_html_with_retry(
            url,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout_sec,
            referer="https://www.amazon.in/",
        )
        if not html:
            html = await self.render_with_playwright(url, wait_selector="#productTitle")

        if not html:
            return None

        soup = BeautifulSoup(html, "html.parser")
        title_el = soup.select_one("#productTitle")
        if not title_el:
            return None

        title = title_el.get_text(strip=True)
        asin = self._extract_asin(url)

        # Price extraction
        price = None
        for sel in ["#corePrice_feature_div span.a-offscreen", ".a-price span.a-offscreen", "#priceblock_dealprice"]:
            el = soup.select_one(sel)
            if el:
                price = clean_price(el.get_text())
                if price:
                    break

        # MRP extraction
        mrp = None
        for sel in [
            "#corePriceDisplay_desktop_feature_div span.a-text-price span.a-offscreen",
            "span.a-text-price span.a-offscreen",
            "#priceblock_ourprice",
        ]:
            el = soup.select_one(sel)
            if el:
                mrp = clean_price(el.get_text())
                if mrp:
                    break

        if not price:
            return None
        if not mrp or mrp < price:
            mrp = price

        discount = self.compute_discount(price, mrp)

        # Rating & reviews
        rating = 0.0
        rating_el = soup.select_one("#acrPopover")
        if rating_el:
            match = re.search(r"(\d+(?:\.\d+)?)", rating_el.get_text())
            if match:
                rating = float(match.group(1))

        reviews = 0
        review_el = soup.select_one("#acrCustomerReviewText")
        if review_el:
            reviews = clean_number(review_el.get_text())

        # Image
        img_el = soup.select_one("#landingImage, #imgBlkFront")
        image_url = img_el.get("src") if img_el else None

        # Seller
        seller = "Amazon Seller"
        seller_el = soup.select_one("#merchant-info, #tabular-buybox-truncate-0 .tabular-buybox-text")
        if seller_el:
            seller = seller_el.get_text(strip=True)[:100]

        # Stock
        avail_el = soup.select_one("#availability")
        in_stock = True
        if avail_el and "currently unavailable" in avail_el.get_text().lower():
            in_stock = False

        return ScrapedProductItem(
            site=self.site_id,
            external_id=asin,
            title=title[:450],
            product_url=url,
            image_url=image_url,
            current_price=price,
            mrp=mrp,
            discount_percent=discount,
            rating=rating,
            review_count=reviews,
            seller=seller,
            in_stock=in_stock,
            category="Product",
        )
