import json
import re
import logging
from typing import List, Optional
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import httpx

from app.scrapers.base import BaseScraper
from app.schemas import ScrapedProductItem
from app.scrapers.utils import (
    get_random_headers,
    clean_price,
    clean_number,
    random_delay,
)

logger = logging.getLogger("deal_finder.scrapers.myntra")


class MyntraScraper(BaseScraper):
    site_id = "myntra"
    name = "Myntra"
    base_url = "https://www.myntra.com"

    def _extract_style_id(self, url: str) -> Optional[str]:
        match = re.search(r"/(\d+)/buy", url)
        if match:
            return match.group(1)
        match2 = re.search(r"/(\d+)$", url)
        return match2.group(1) if match2 else None

    async def scrape_category(self, url: str, category_name: str) -> List[ScrapedProductItem]:
        """
        Scrape deals from Myntra. Tries internal search data / JSON first,
        falling back to Playwright rendering.
        """
        logger.info(f"[{self.name}] Scraping category '{category_name}' from: {url}")
        items: List[ScrapedProductItem] = []

        # 1. First attempt: fetch page HTML and look for window.__myx JSON payload
        html = None
        try:
            headers = get_random_headers(referer="https://www.myntra.com/")
            async with httpx.AsyncClient(headers=headers, timeout=self.config.timeout_sec, follow_redirects=True) as client:
                resp = await client.get(url)
                if resp.status_code == 200:
                    html = resp.text
        except Exception as e:
            logger.warning(f"[{self.name}] httpx request failed for {url}: {e}")

        # Check for window.__myx script object
        if html:
            items = self._parse_embedded_json(html, category_name)

        # 2. If no items extracted, use Playwright
        if not items:
            html = await self.render_with_playwright(
                url,
                wait_selector="ul.results-base, li.product-base",
            )
            if html:
                items = self._parse_rendered_html(html, category_name)

        logger.info(f"[{self.name}] Extracted {len(items)} items from '{category_name}'")
        await random_delay(self.config.min_delay_sec, self.config.max_delay_sec)
        return items

    def _parse_embedded_json(self, html: str, category_name: str) -> List[ScrapedProductItem]:
        items: List[ScrapedProductItem] = []
        try:
            match = re.search(r"window\.__myx\s*=\s*(\{.*?\});\s*</script>", html, re.DOTALL)
            if not match:
                return items

            data = json.loads(match.group(1))
            search_data = data.get("searchData", {})
            products = search_data.get("results", {}).get("products", [])

            for p in products:
                try:
                    product_id = str(p.get("productId", ""))
                    brand = p.get("brand", "")
                    name = p.get("additionalInfo", "") or p.get("productName", "")
                    title = f"{brand} {name}".strip()

                    landing_url = p.get("landingPageUrl", "")
                    full_url = urljoin(self.base_url, landing_url) if landing_url else f"https://www.myntra.com/{product_id}/buy"

                    price = float(p.get("price", 0))
                    mrp = float(p.get("mrp", price))
                    if mrp < price or mrp == 0:
                        mrp = price

                    discount = self.compute_discount(price, mrp)
                    rating = float(p.get("rating", 0.0) or 0.0)
                    rating_count = int(p.get("ratingCount", 0) or 0)
                    image_url = p.get("searchImage")

                    # Check inventory
                    inventory = p.get("inventoryInfo", [])
                    in_stock = True
                    if inventory and isinstance(inventory, list):
                        total_qty = sum(item.get("inventory", 0) for item in inventory if isinstance(item, dict))
                        in_stock = total_qty > 0

                    items.append(
                        ScrapedProductItem(
                            site=self.site_id,
                            external_id=product_id,
                            title=title[:450],
                            product_url=full_url,
                            image_url=image_url,
                            current_price=price,
                            mrp=mrp,
                            discount_percent=discount,
                            rating=round(rating, 1),
                            review_count=rating_count,
                            seller="Myntra Verified",
                            in_stock=in_stock,
                            category=category_name,
                        )
                    )
                except Exception as p_err:
                    logger.debug(f"Myntra json product parse error: {p_err}")
                    continue
        except Exception as e:
            logger.debug(f"Failed to parse window.__myx on Myntra: {e}")

        return items

    def _parse_rendered_html(self, html: str, category_name: str) -> List[ScrapedProductItem]:
        items: List[ScrapedProductItem] = []
        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select("li.product-base")

        for card in cards:
            try:
                link_el = card.select_one("a[href*='/buy'], a")
                if not link_el:
                    continue

                raw_href = link_el.get("href", "")
                full_url = urljoin(self.base_url, raw_href)
                style_id = self._extract_style_id(full_url)

                brand_el = card.select_one("h3.product-brand")
                name_el = card.select_one("h4.product-product")
                brand = brand_el.get_text(strip=True) if brand_el else ""
                name = name_el.get_text(strip=True) if name_el else ""
                title = f"{brand} {name}".strip()
                if not title:
                    title = "Fashion Item"

                price_el = card.select_one("span.product-discountedPrice")
                mrp_el = card.select_one("span.product-strike")

                if price_el:
                    price = clean_price(price_el.get_text())
                else:
                    price_fallback = card.select_one("div.product-price span")
                    price = clean_price(price_fallback.get_text()) if price_fallback else None

                if not price:
                    continue

                mrp = clean_price(mrp_el.get_text()) if mrp_el else price
                if not mrp or mrp < price:
                    mrp = price

                discount = self.compute_discount(price, mrp)

                # Rating
                rating = 0.0
                rating_el = card.select_one("div.product-ratingsContainer span")
                if rating_el:
                    m = re.search(r"(\d+(?:\.\d+)?)", rating_el.get_text())
                    if m:
                        rating = float(m.group(1))

                # Reviews
                reviews = 0
                rev_el = card.select_one("div.product-ratingsCount")
                if rev_el:
                    reviews = clean_number(rev_el.get_text())

                # Image
                img_el = card.select_one("picture img, img.img-responsive")
                image_url = img_el.get("src") if img_el else None

                items.append(
                    ScrapedProductItem(
                        site=self.site_id,
                        external_id=style_id,
                        title=title[:450],
                        product_url=full_url,
                        image_url=image_url,
                        current_price=price,
                        mrp=mrp,
                        discount_percent=discount,
                        rating=rating,
                        review_count=reviews,
                        seller="Myntra Verified",
                        in_stock=True,
                        category=category_name,
                    )
                )
            except Exception as e:
                logger.debug(f"Error parsing rendered Myntra card: {e}")
                continue

        return items

    async def fetch_product(self, url: str) -> Optional[ScrapedProductItem]:
        """Fetch single Myntra product page details."""
        html = await self.render_with_playwright(url, wait_selector="h1.pdp-title")
        if not html:
            return None

        soup = BeautifulSoup(html, "html.parser")
        brand_el = soup.select_one("h1.pdp-title")
        name_el = soup.select_one("h1.pdp-name")
        brand = brand_el.get_text(strip=True) if brand_el else ""
        name = name_el.get_text(strip=True) if name_el else ""
        title = f"{brand} {name}".strip()

        price_el = soup.select_one("span.pdp-price strong")
        price = clean_price(price_el.get_text()) if price_el else None
        if not price:
            return None

        mrp_el = soup.select_one("span.pdp-mrp s")
        mrp = clean_price(mrp_el.get_text()) if mrp_el else price
        if not mrp or mrp < price:
            mrp = price

        discount = self.compute_discount(price, mrp)

        rating_el = soup.select_one("div.index-overallRating div")
        rating = clean_price(rating_el.get_text()) if rating_el else 0.0

        rev_el = soup.select_one("div.index-ratingsCount")
        reviews = clean_number(rev_el.get_text()) if rev_el else 0

        img_el = soup.select_one("div.image-grid-image")
        image_url = None
        if img_el:
            style_str = img_el.get("style", "")
            match = re.search(r'url\(["\']?(.*?)["\']?\)', style_str)
            if match:
                image_url = match.group(1)

        return ScrapedProductItem(
            site=self.site_id,
            external_id=self._extract_style_id(url),
            title=title[:450],
            product_url=url,
            image_url=image_url,
            current_price=price,
            mrp=mrp,
            discount_percent=discount,
            rating=rating,
            review_count=reviews,
            seller="Myntra",
            in_stock=True,
            category="Fashion",
        )
