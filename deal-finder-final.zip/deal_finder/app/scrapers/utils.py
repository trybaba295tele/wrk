import re
import random
import asyncio
import logging
from typing import Optional, Dict
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
import httpx

logger = logging.getLogger("deal_finder.scrapers.utils")

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
]


def get_random_headers(referer: Optional[str] = None) -> Dict[str, str]:
    """Generate realistic browser headers to bypass naive bot detection."""
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,hi;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
        "Sec-Ch-Ua-Mobile": "?0",
        "Sec-Ch-Ua-Platform": '"Windows"',
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-User": "?1",
    }
    if referer:
        headers["Referer"] = referer
    return headers


async def random_delay(min_sec: float = 2.0, max_sec: float = 5.0) -> None:
    """Pause execution for a random interval to mimic human behavior."""
    delay = random.uniform(min_sec, max_sec)
    await asyncio.sleep(delay)


def clean_price(price_input) -> Optional[float]:
    """
    Extract numeric price from messy text like '₹ 1,499.00', 'Rs. 499', '1,299 off'.
    """
    if price_input is None:
        return None
    if isinstance(price_input, (int, float)):
        return float(price_input)

    text = str(price_input).replace(",", "").replace("\xa0", " ").strip()
    match = re.search(r"(\d+(?:\.\d{1,2})?)", text)
    if match:
        try:
            val = float(match.group(1))
            return val if val > 0 else None
        except ValueError:
            return None
    return None


def clean_number(num_input) -> int:
    """Extract integer count from strings like '(1,452 ratings)', '1.2k'."""
    if num_input is None:
        return 0
    if isinstance(num_input, int):
        return num_input

    text = str(num_input).lower().replace(",", "").replace("(", "").replace(")", "").strip()
    match_k = re.search(r"(\d+(?:\.\d+)?)\s*k", text)
    if match_k:
        try:
            return int(float(match_k.group(1)) * 1000)
        except ValueError:
            pass

    match = re.search(r"\d+", text)
    if match:
        try:
            return int(match.group(0))
        except ValueError:
            return 0
    return 0


def build_affiliate_url(url: str, site: str, affiliate_config) -> str:
    """Inject the affiliate tag into product URLs."""
    if not url:
        return ""
    try:
        parsed = urlparse(url)
        query = parse_qs(parsed.query)

        site_lower = site.lower()
        if "amazon" in site_lower and affiliate_config.amazon_tag:
            query["tag"] = [affiliate_config.amazon_tag]
        elif "flipkart" in site_lower and affiliate_config.flipkart_tag:
            query["affid"] = [affiliate_config.flipkart_tag]
        elif "myntra" in site_lower and affiliate_config.myntra_tag:
            query["utm_source"] = ["affiliate"]
            query["utm_medium"] = [affiliate_config.myntra_tag]

        new_query = urlencode(query, doseq=True)
        return urlunparse(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path,
                parsed.params,
                new_query,
                parsed.fragment,
            )
        )
    except Exception as e:
        logger.warning(f"Failed to build affiliate URL for {url}: {e}")
        return url


async def fetch_html_with_retry(
    url: str,
    max_retries: int = 3,
    timeout: int = 25,
    referer: Optional[str] = None,
) -> Optional[str]:
    """
    Fetch URL with httpx using exponential backoff retry and anti-bot checks.
    Returns HTML content or None if blocked/failed.
    """
    backoff = 2.0
    for attempt in range(1, max_retries + 1):
        try:
            headers = get_random_headers(referer=referer)
            async with httpx.AsyncClient(
                headers=headers,
                timeout=timeout,
                follow_redirects=True,
                http2=True,
            ) as client:
                response = await client.get(url)

                # Check for rate limiting / challenges
                if response.status_code in (429, 503):
                    logger.warning(
                        f"Rate limit or 503 encountered for {url} (attempt {attempt}/{max_retries}). Backing off {backoff:.1f}s"
                    )
                    await asyncio.sleep(backoff)
                    backoff *= 2
                    continue

                if response.status_code == 200:
                    html = response.text
                    # Check for typical Captcha traps
                    if "api-services-support@amazon.com" in html or "Type the characters you see in this image" in html:
                        logger.warning(f"Amazon Captcha detected on {url}. Skipping or delegating to browser.")
                        return None
                    return html

                logger.debug(f"HTTP status {response.status_code} for {url}")
        except (httpx.RequestError, httpx.TimeoutException) as exc:
            logger.warning(f"Network error on {url} (attempt {attempt}/{max_retries}): {exc}")
            await asyncio.sleep(backoff)
            backoff *= 2
        except Exception as e:
            logger.error(f"Unexpected error fetching {url}: {e}")
            break

    return None
