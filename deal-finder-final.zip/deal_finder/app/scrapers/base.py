import logging
import asyncio
from abc import ABC, abstractmethod
from typing import List, Optional
from playwright.async_api import async_playwright, Browser, Page

from app.schemas import ScrapedProductItem
from app.config import settings
from app.scrapers.utils import get_random_headers

logger = logging.getLogger("deal_finder.scrapers.base")


class BaseScraper(ABC):
    """
    Abstract Base Class for all e-commerce scrapers.
    Defines common scraping, normalization, and browser fallback behavior.
    """

    site_id: str = "generic"
    name: str = "Generic Store"

    def __init__(self):
        self.config = settings.scraper

    @abstractmethod
    async def scrape_category(self, url: str, category_name: str) -> List[ScrapedProductItem]:
        """
        Scrape deals and products from a category, search, or deal page.
        Must return a list of validated ScrapedProductItem models.
        """
        pass

    @abstractmethod
    async def fetch_product(self, url: str) -> Optional[ScrapedProductItem]:
        """
        Fetch details for an individual product URL.
        """
        pass

    def compute_discount(self, price: float, mrp: float) -> float:
        """Calculate discount percentage accurately."""
        if mrp <= 0 or price <= 0 or price >= mrp:
            return 0.0
        pct = ((mrp - price) / mrp) * 100.0
        return round(pct, 2)

    async def render_with_playwright(
        self,
        url: str,
        wait_selector: Optional[str] = None,
        timeout_ms: int = 30000,
    ) -> Optional[str]:
        """
        Fallback renderer using headless Playwright for JavaScript-rendered SPAs
        or pages protected by lightweight challenge scripts.
        """
        if not self.config.use_playwright_fallback:
            return None

        logger.info(f"[{self.name}] Falling back to Playwright headless browser for {url}")
        try:
            async with async_playwright() as p:
                browser: Browser = await p.chromium.launch(
                    headless=self.config.headless,
                    args=[
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-dev-shm-usage",
                        "--disable-blink-features=AutomationControlled",
                    ],
                )
                headers = get_random_headers()
                context = await browser.new_context(
                    user_agent=headers["User-Agent"],
                    viewport={"width": 1440, "height": 900},
                    locale="en-IN",
                )
                page: Page = await context.new_page()

                # Anti-detection override
                await page.add_init_script(
                    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
                )

                await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)

                if wait_selector:
                    try:
                        await page.wait_for_selector(wait_selector, timeout=8000)
                    except Exception:
                        logger.debug(f"Selector '{wait_selector}' not found within timeout on {url}")

                # Scroll down slightly to trigger lazy-loaded product grids
                await page.evaluate("window.scrollBy(0, 800)")
                await asyncio.sleep(1.5)

                content = await page.content()
                await browser.close()
                return content
        except Exception as e:
            logger.error(f"[{self.name}] Playwright rendering failed for {url}: {e}")
            return None
