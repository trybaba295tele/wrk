import os
import re
import logging
from typing import List, Optional
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse, parse_qs

from app.scrapers.base import BaseScraper
from app.schemas import ScrapedProductItem
from app.scrapers.utils import (
    fetch_html_with_retry,
    clean_price,
    clean_number,
    random_delay,
)

logger = logging.getLogger("deal_finder.scrapers.flipkart")


class FlipkartScraper(BaseScraper):
    site_id = "flipkart"
    name = "Flipkart India"
    base_url = "https://www.flipkart.com"

    def __init__(self):
        super().__init__()
        self.affiliate_id = os.getenv("FLIPKART_AFFILIATE_ID")
        self.affiliate_token = os.getenv("FLIPKART_AFFILIATE_TOKEN")

    def _extract_pid(self, url: str) -> Optional[str]:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        if "pid" in params:
            return params["pid"][0]
        match = re.search(r"/(?:itm|p)/([A-Za-z0-9]{16})", url)
        return match.group(1) if match else None

    async def scrape_category(self, url: str, category_name: str) -> List[ScrapedProductItem]:
        """
        Scrape deals from Flipkart listing and offer store pages.
        """
        logger.info(f"[{self.name}] Scraping category '{category_name}' from: {url}")
        items: List[ScrapedProductItem] = []

        html = await fetch_html_with_retry(
            url,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout_sec,
            referer="https://www.flipkart.com/",
        )

        if not html:
            html = await self.render_with_playwright(
                url,
                wait_selector="div[data-id], div._1AtVbE, div._75nlfW",
            )

        if not html:
            logger.warning(f"[{self.name}] Could not retrieve page content for: {url}")
            return items

        soup = BeautifulSoup(html, "html.parser")

        # Flipkart products typically render within div[data-id] or grid cards
        product_cards = soup.select("div[data-id]")
        if not product_cards:
            product_cards = soup.select("div._1AtVbE div._13oc-S, div._75nlfW, div._1xHGtK")

        for card in product_cards:
            try:
                pid = card.get("data-id")

                # Title & link
                link_el = card.select_one(
                    "a[href*='/p/'], a[href*='pid='], a._1fQZEK, a.s1Q9Wh, a.IRpwTa, a.VJA3rP"
                )
                if not link_el:
                    continue

                raw_href = link_el.get("href", "")
                if not raw_href:
                    continue

                full_url = urljoin(self.base_url, raw_href)
                # Strip dynamic query tracking parameters but preserve pid
                parsed_url = urlparse(full_url)
                qs = parse_qs(parsed_url.query)
                clean_query = f"pid={qs['pid'][0]}" if "pid" in qs else ""
                clean_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
                if clean_query:
                    clean_url += f"?{clean_query}"

                if not pid:
                    pid = self._extract_pid(full_url)

                title_el = card.select_one(
                    "div._4rR01T, a.s1Q9Wh, a.IRpwTa, div.KzDlHZ, div._2WkVRV, div.wjcEIp"
                )
                title = title_el.get_text(strip=True) if title_el else link_el.get("title", "")
                if not title:
                    title = link_el.get_text(strip=True)
                if not title:
                    continue

                # Current Price
                price_el = card.select_one("div._30jeq3, div.Nx9bqj, div._1vC4OE")
                if not price_el:
                    continue
                price = clean_price(price_el.get_text())
                if not price:
                    continue

                # MRP (original crossed out price)
                mrp_el = card.select_one("div._3I9_wc, div.yRaY8j, div._3auQ3N")
                mrp = clean_price(mrp_el.get_text()) if mrp_el else price
                if not mrp or mrp < price:
                    mrp = price

                discount = self.compute_discount(price, mrp)

                # Rating
                rating = 0.0
                rating_el = card.select_one("div._3LWZlK, div.XQDdHH")
                if rating_el:
                    match_r = re.search(r"(\d+(?:\.\d+)?)", rating_el.get_text())
                    if match_r:
                        rating = float(match_r.group(1))

                # Reviews / Ratings count
                reviews = 0
                review_el = card.select_one("span._2_R_DZ, span.Wphh3Z")
                if review_el:
                    reviews = clean_number(review_el.get_text())

                # Image
                image_url = None
                img_el = card.select_one("img._396cs4, img.DByuf4, img._2r_T1I")
                if img_el:
                    image_url = img_el.get("src") or img_el.get("data-src")

                # In stock status
                card_text = card.get_text().lower()
                in_stock = not ("sold out" in card_text or "out of stock" in card_text)

                items.append(
                    ScrapedProductItem(
                        site=self.site_id,
                        external_id=pid,
                        title=title[:450],
                        product_url=clean_url,
                        image_url=image_url,
                        current_price=price,
                        mrp=mrp,
                        discount_percent=discount,
                        rating=rating,
                        review_count=reviews,
                        seller="Flipkart Assured",
                        in_stock=in_stock,
                        category=category_name,
                    )
                )
            except Exception as item_err:
                logger.debug(f"Error parsing Flipkart product item: {item_err}")
                continue

        logger.info(f"[{self.name}] Extracted {len(items)} items from '{category_name}'")
        await random_delay(self.config.min_delay_sec, self.config.max_delay_sec)
        return items

    async def fetch_product(self, url: str) -> Optional[ScrapedProductItem]:
        """Fetch single Flipkart product details."""
        html = await fetch_html_with_retry(
            url,
            max_retries=self.config.max_retries,
            timeout=self.config.timeout_sec,
            referer="https://www.flipkart.com/",
        )
        if not html:
            html = await self.render_with_playwright(url, wait_selector="span.B_NuCI, h1.M-67kW")

        if not html:
            return None

        soup = BeautifulSoup(html, "html.parser")
        title_el = soup.select_one("span.B_NuCI, h1.M-67kW, span._35KyD6")
        if not title_el:
            return None

        title = title_el.get_text(strip=True)
        pid = self._extract_pid(url)

        price_el = soup.select_one("div._30jeq3._16Jk6d, div.Nx9bqj.CxhGGd")
        price = clean_price(price_el.get_text()) if price_el else None
        if not price:
            return None

        mrp_el = soup.select_one("div._3I9_wc._2p6cR8, div.yRaY8j.A6+E68")
        mrp = clean_price(mrp_el.get_text()) if mrp_el else price
        if not mrp or mrp < price:
            mrp = price

        discount = self.compute_discount(price, mrp)

        rating_el = soup.select_one("div._3LWZlK, div.XQDdHH")
        rating = 0.0
        if rating_el:
            m = re.search(r"(\d+(?:\.\d+)?)", rating_el.get_text())
            if m:
                rating = float(m.group(1))

        review_el = soup.select_one("span._2_R_DZ span:nth-of-type(4), span.Wphh3Z")
        reviews = clean_number(review_el.get_text()) if review_el else 0

        img_el = soup.select_one("img._396cs4._2amPTt, img.DByuf4")
        image_url = img_el.get("src") if img_el else None

        seller_el = soup.select_one("#sellerName span span, div._1RLviY")
        seller = seller_el.get_text(strip=True) if seller_el else "Flipkart Seller"

        out_of_stock = bool(soup.select("div._16FRp0, div._1-2aD4"))

        return ScrapedProductItem(
            site=self.site_id,
            external_id=pid,
            title=title[:450],
            product_url=url,
            image_url=image_url,
            current_price=price,
            mrp=mrp,
            discount_percent=discount,
            rating=rating,
            review_count=reviews,
            seller=seller,
            in_stock=not out_of_stock,
            category="Product",
        )
