from datetime import datetime, timezone
from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    DateTime,
    ForeignKey,
    Text,
    Index,
)
from sqlalchemy.orm import relationship
from app.database import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    site = Column(String(50), nullable=False, index=True)  # amazon, flipkart, myntra
    external_id = Column(String(100), nullable=True, index=True)  # ASIN / FSN / PID
    title = Column(String(500), nullable=False)
    product_url = Column(Text, nullable=False, unique=True)
    affiliate_url = Column(Text, nullable=True)
    image_url = Column(Text, nullable=True)

    current_price = Column(Float, nullable=False)
    mrp = Column(Float, nullable=False)
    discount_percent = Column(Float, nullable=False, default=0.0)

    rating = Column(Float, nullable=True, default=0.0)
    review_count = Column(Integer, nullable=True, default=0)
    seller = Column(String(255), nullable=True, default="Unknown")
    in_stock = Column(Boolean, nullable=False, default=True)
    category = Column(String(100), nullable=True, index=True)

    # Deal flags & detection metrics
    is_deal = Column(Boolean, default=False, index=True)
    deal_type = Column(String(50), nullable=True)  # HEAVY_DISCOUNT, MRP_ERROR, COMBO
    confidence_score = Column(Float, default=0.0)
    deal_reason = Column(Text, nullable=True)

    created_at = Column(DateTime, default=utc_now, nullable=False)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now, nullable=False)

    # Relationships
    price_history = relationship(
        "PriceHistory",
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="PriceHistory.timestamp.desc()",
    )
    alerts = relationship(
        "DealAlert",
        back_populates="product",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("idx_site_deal", "site", "is_deal"),
        Index("idx_confidence", "confidence_score"),
    )


class PriceHistory(Base):
    __tablename__ = "price_history"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    price = Column(Float, nullable=False)
    mrp = Column(Float, nullable=False)
    discount_percent = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=utc_now, nullable=False, index=True)

    product = relationship("Product", back_populates="price_history")


class DealAlert(Base):
    __tablename__ = "deal_alerts"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    channel = Column(String(50), default="TELEGRAM", nullable=False)
    sent_at = Column(DateTime, default=utc_now, nullable=False)
    price_at_alert = Column(Float, nullable=False)
    discount_at_alert = Column(Float, nullable=False)
    confidence_score = Column(Float, nullable=False)

    product = relationship("Product", back_populates="alerts")
