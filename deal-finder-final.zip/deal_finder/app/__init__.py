"""Deal Finder Pro Application Package"""
__version__ = "1.0.0"
