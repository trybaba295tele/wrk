// Deal Finder Pro Dashboard Application

let currentFilters = {
  site: "all",
  search: "",
  dealType: "all",
  minDiscount: 50,
  maxPrice: null,
  sortBy: "confidence",
};

let countdownSeconds = 30;
let countdownTimer = null;
let priceChartInstance = null;

// DOM Elements
const dealsGrid = document.getElementById("dealsGrid");
const loadingIndicator = document.getElementById("loadingIndicator");
const emptyState = document.getElementById("emptyState");
const siteTabs = document.querySelectorAll(".site-tab");
const searchInput = document.getElementById("searchInput");
const dealTypeSelect = document.getElementById("dealTypeSelect");
const minDiscountSlider = document.getElementById("minDiscountSlider");
const minDiscountLabel = document.getElementById("minDiscountLabel");
const maxPriceInput = document.getElementById("maxPriceInput");
const sortBySelect = document.getElementById("sortBySelect");
const scanBtn = document.getElementById("scanBtn");
const scanIcon = document.getElementById("scanIcon");
const countdownText = document.getElementById("countdownText");

// Stats Elements
const statTotal = document.getElementById("statTotal");
const statMrpErrors = document.getElementById("statMrpErrors");
const statHeavy = document.getElementById("statHeavy");
const statActive = document.getElementById("statActive");

// Modal Elements
const chartModal = document.getElementById("chartModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const modalProductTitle = document.getElementById("modalProductTitle");
const modalSiteBadge = document.getElementById("modalSiteBadge");
const modalCurrentPrice = document.getElementById("modalCurrentPrice");
const modalMrpPrice = document.getElementById("modalMrpPrice");
const modalBuyLink = document.getElementById("modalBuyLink");

// Initialize application
document.addEventListener("DOMContentLoaded", () => {
  setupEventListeners();
  fetchStats();
  fetchDeals();
  startCountdown();
});

function setupEventListeners() {
  // Site Filter Tabs
  siteTabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      siteTabs.forEach((t) => {
        t.classList.remove("bg-rose-600", "text-white");
        t.classList.add("text-slate-400");
      });
      tab.classList.add("bg-rose-600", "text-white");
      tab.classList.remove("text-slate-400");

      currentFilters.site = tab.getAttribute("data-site");
      fetchDeals();
    });
  });

  // Search input debounced
  let debounceTimeout = null;
  searchInput.addEventListener("input", (e) => {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
      currentFilters.search = e.target.value.trim().toLowerCase();
      renderCurrentDeals();
    }, 250);
  });

  // Deal type selector
  dealTypeSelect.addEventListener("change", (e) => {
    currentFilters.dealType = e.target.value;
    fetchDeals();
  });

  // Min discount slider
  minDiscountSlider.addEventListener("input", (e) => {
    minDiscountLabel.textContent = `${e.target.value}%`;
  });
  minDiscountSlider.addEventListener("change", (e) => {
    currentFilters.minDiscount = parseFloat(e.target.value);
    fetchDeals();
  });

  // Max price input
  maxPriceInput.addEventListener("change", (e) => {
    const val = e.target.value ? parseFloat(e.target.value) : null;
    currentFilters.maxPrice = val;
    fetchDeals();
  });

  // Sort By select
  sortBySelect.addEventListener("change", (e) => {
    currentFilters.sortBy = e.target.value;
    fetchDeals();
  });

  // Manual Scan trigger
  scanBtn.addEventListener("click", async () => {
    triggerScan();
  });

  // Modal close
  closeModalBtn.addEventListener("click", closeChartModal);
  chartModal.addEventListener("click", (e) => {
    if (e.target === chartModal) closeChartModal();
  });
}

function startCountdown() {
  clearInterval(countdownTimer);
  countdownSeconds = 30;
  countdownText.textContent = `${countdownSeconds}s`;

  countdownTimer = setInterval(() => {
    countdownSeconds -= 1;
    if (countdownSeconds <= 0) {
      countdownSeconds = 30;
      fetchStats();
      fetchDeals(false);
    }
    countdownText.textContent = `${countdownSeconds}s`;
  }, 1000);
}

async function fetchStats() {
  try {
    const res = await fetch("/api/stats");
    if (!res.ok) return;
    const data = await res.json();
    statTotal.textContent = data.total_products_tracked.toLocaleString();
    statMrpErrors.textContent = data.mrp_errors_count.toLocaleString();
    statHeavy.textContent = data.heavy_discounts_count.toLocaleString();
    statActive.textContent = data.active_deals_count.toLocaleString();
  } catch (err) {
    console.error("Failed to fetch system stats:", err);
  }
}

let cachedDeals = [];

async function fetchDeals(showLoader = true) {
  if (showLoader) {
    loadingIndicator.classList.remove("hidden");
    dealsGrid.innerHTML = "";
    emptyState.classList.add("hidden");
  }

  const params = new URLSearchParams();
  if (currentFilters.site !== "all") params.append("site", currentFilters.site);
  if (currentFilters.dealType !== "all") params.append("deal_type", currentFilters.dealType);
  if (currentFilters.minDiscount) params.append("min_discount", currentFilters.minDiscount);
  if (currentFilters.maxPrice) params.append("max_price", currentFilters.maxPrice);
  params.append("sort_by", currentFilters.sortBy);

  try {
    const res = await fetch(`/api/deals?${params.toString()}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    cachedDeals = data.deals || [];
    renderCurrentDeals();
  } catch (err) {
    console.error("Error fetching deals:", err);
  } finally {
    loadingIndicator.classList.add("hidden");
  }
}

function renderCurrentDeals() {
  let filtered = cachedDeals;

  if (currentFilters.search) {
    filtered = filtered.filter(
      (d) =>
        d.title.toLowerCase().includes(currentFilters.search) ||
        (d.category && d.category.toLowerCase().includes(currentFilters.search)) ||
        (d.seller && d.seller.toLowerCase().includes(currentFilters.search))
    );
  }

  if (filtered.length === 0) {
    dealsGrid.innerHTML = "";
    emptyState.classList.remove("hidden");
    return;
  }

  emptyState.classList.add("hidden");
  dealsGrid.innerHTML = filtered.map((deal) => createDealCardHtml(deal)).join("");

  // Attach dynamic event listeners to card action buttons
  document.querySelectorAll(".price-history-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prodId = btn.getAttribute("data-id");
      const dealObj = cachedDeals.find((d) => d.id == prodId);
      if (dealObj) openPriceChart(dealObj);
    });
  });
}

function getSiteBadge(site) {
  const s = site.toLowerCase();
  if (s === "amazon") {
    return `<span class="bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1">
      <i class="fa-brands fa-amazon"></i> Amazon
    </span>`;
  } else if (s === "flipkart") {
    return `<span class="bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1">
      <i class="fa-solid fa-bag-shopping"></i> Flipkart
    </span>`;
  } else if (s === "myntra") {
    return `<span class="bg-pink-500/10 text-pink-400 border border-pink-500/30 px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1">
      <i class="fa-solid fa-shirt"></i> Myntra
    </span>`;
  }
  return `<span class="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[11px] font-semibold">${site}</span>`;
}

function createDealCardHtml(deal) {
  const isMrpGlitch = (deal.deal_type || "").includes("MRP");
  const savings = Math.max(0, deal.mrp - deal.current_price);
  const confidenceColor =
    deal.confidence_score >= 85
      ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/30"
      : deal.confidence_score >= 70
      ? "text-amber-400 bg-amber-500/10 border-amber-500/30"
      : "text-slate-400 bg-slate-800 border-slate-700";

  const targetLink = deal.affiliate_url || deal.product_url;
  const imageFallback = "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=400&q=80";

  return `
    <article class="deal-card bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col justify-between">
      <!-- Card Header -->
      <div class="p-4 space-y-3">
        <div class="flex items-center justify-between gap-2">
          ${getSiteBadge(deal.site)}
          <div class="flex items-center gap-1.5">
            ${
              isMrpGlitch
                ? `<span class="mrp-glitch-badge text-white font-bold text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                    <i class="fa-solid fa-triangle-exclamation"></i> MRP Error
                   </span>`
                : `<span class="heavy-deal-badge text-white font-bold text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1">
                    <i class="fa-solid fa-fire"></i> Heavy Deal
                   </span>`
            }
            <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${confidenceColor}" title="AI Deal Confidence Score">
              ${deal.confidence_score.toFixed(0)}% Match
            </span>
          </div>
        </div>

        <!-- Product Image & Basic Info -->
        <div class="flex gap-3">
          <div class="w-20 h-20 sm:w-24 sm:h-24 bg-slate-950 rounded-lg overflow-hidden shrink-0 flex items-center justify-center border border-slate-800">
            <img src="${deal.image_url || imageFallback}" alt="${deal.title}"
              class="w-full h-full object-cover"
              onerror="this.src='${imageFallback}'">
          </div>
          <div class="flex-1 min-w-0">
            <a href="${targetLink}" target="_blank" rel="noopener noreferrer"
              class="text-xs sm:text-sm font-semibold text-slate-100 hover:text-rose-400 line-clamp-2 transition leading-snug">
              ${deal.title}
            </a>

            <!-- Rating & Reviews -->
            <div class="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
              <span class="text-amber-400 flex items-center gap-0.5 font-medium">
                <i class="fa-solid fa-star text-[10px]"></i> ${deal.rating ? deal.rating.toFixed(1) : "N/A"}
              </span>
              <span>•</span>
              <span>${deal.review_count ? deal.review_count.toLocaleString() : 0} reviews</span>
            </div>

            <!-- Seller -->
            <p class="text-[10px] text-slate-400 truncate mt-0.5">
              Seller: <span class="text-slate-300 font-medium">${deal.seller || "Verified Retailer"}</span>
            </p>
          </div>
        </div>

        <!-- Price Breakdown -->
        <div class="bg-slate-950/70 rounded-lg p-2.5 border border-slate-800/80 flex items-baseline justify-between">
          <div>
            <div class="text-lg sm:text-xl font-black text-rose-400 font-mono">
              ₹${deal.current_price.toLocaleString("en-IN")}
            </div>
            <div class="text-[11px] text-slate-400 flex items-center gap-2">
              <span class="line-through text-slate-400">₹${deal.mrp.toLocaleString("en-IN")}</span>
              <span class="text-emerald-400 font-medium">Save ₹${savings.toLocaleString("en-IN")}</span>
            </div>
          </div>
          <div class="text-right">
            <span class="bg-rose-500/20 text-rose-300 text-xs font-black px-2 py-1 rounded-md border border-rose-500/40">
              ${deal.discount_percent.toFixed(0)}% OFF
            </span>
          </div>
        </div>

        <!-- Deal Reason Pill -->
        <p class="text-[11px] text-slate-400 bg-slate-800/50 rounded-md p-2 border border-slate-800/70 leading-relaxed">
          <i class="fa-solid fa-circle-info text-amber-400 text-[10px] mr-1"></i>
          <span class="text-slate-300">${deal.deal_reason || "Price drops below regular market threshold"}</span>
        </p>
      </div>

      <!-- Card Action Buttons -->
      <div class="px-4 py-3 bg-slate-950/50 border-t border-slate-800 flex items-center justify-between gap-2">
        <button class="price-history-btn text-xs text-slate-400 hover:text-white px-2.5 py-1.5 rounded-lg border border-slate-700/60 hover:border-slate-500 transition flex items-center gap-1.5"
          data-id="${deal.id}">
          <i class="fa-solid fa-chart-line text-[11px] text-indigo-400"></i>
          <span>Price History</span>
        </button>

        <a href="${targetLink}" target="_blank" rel="noopener noreferrer"
          class="bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-semibold text-xs px-3.5 py-1.5 rounded-lg shadow transition flex items-center gap-1">
          <span>Buy Now</span>
          <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
        </a>
      </div>
    </article>
  `;
}

async function openPriceChart(deal) {
  modalProductTitle.textContent = deal.title;
  modalSiteBadge.textContent = deal.site.toUpperCase();
  modalCurrentPrice.textContent = `₹${deal.current_price.toLocaleString("en-IN")}`;
  modalMrpPrice.textContent = `₹${deal.mrp.toLocaleString("en-IN")}`;
  modalBuyLink.href = deal.affiliate_url || deal.product_url;

  chartModal.classList.remove("hidden");

  try {
    const res = await fetch(`/api/products/${deal.id}/history`);
    if (!res.ok) throw new Error("Failed to load history");
    const history = await res.json();

    const labels = history.map((h) => {
      const d = new Date(h.timestamp);
      return `${d.getDate()}/${d.getMonth() + 1}`;
    });
    const prices = history.map((h) => h.price);

    const ctx = document.getElementById("priceHistoryChart").getContext("2d");
    if (priceChartInstance) {
      priceChartInstance.destroy();
    }

    priceChartInstance = new Chart(ctx, {
      type: "line",
      data: {
        labels: labels.length ? labels : ["Current"],
        datasets: [
          {
            label: "Price (₹)",
            data: prices.length ? prices : [deal.current_price],
            borderColor: "#f43f5e",
            backgroundColor: "rgba(244, 63, 94, 0.15)",
            borderWidth: 2.5,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: "#fb7185",
            pointRadius: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (context) => ` ₹${context.parsed.y.toLocaleString("en-IN")}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: "rgba(51, 65, 85, 0.4)" },
            ticks: { color: "#94a3b8", font: { size: 10 } },
          },
          y: {
            grid: { color: "rgba(51, 65, 85, 0.4)" },
            ticks: {
              color: "#94a3b8",
              font: { size: 10 },
              callback: (val) => `₹${val.toLocaleString("en-IN")}`,
            },
          },
        },
      },
    });
  } catch (err) {
    console.error("Failed to render chart:", err);
  }
}

function closeChartModal() {
  chartModal.classList.add("hidden");
}

async function triggerScan() {
  scanIcon.classList.add("fa-spin");
  scanBtn.disabled = true;

  try {
    const res = await fetch("/api/scan/trigger", { method: "POST" });
    const data = await res.json();
    alert(`Deal scan triggered: ${data.message}`);
    setTimeout(() => {
      fetchStats();
      fetchDeals();
    }, 4000);
  } catch (err) {
    console.error("Error triggering scan:", err);
    alert("Failed to trigger scan. Check server logs.");
  } finally {
    scanIcon.classList.remove("fa-spin");
    scanBtn.disabled = false;
  }
}
