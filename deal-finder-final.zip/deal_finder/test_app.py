import asyncio
from httpx import AsyncClient, ASGITransport
from app.main import app

async def run_checks():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # Check 1: Dashboard HTML
        res = await client.get("/")
        assert res.status_code == 200, f"Expected 200, got {res.status_code}"
        assert "Deal Finder Pro" in res.text
        print("[PASS] 1. Dashboard Homepage (/) -> 200 OK")

        # Check 2: Stats API
        res = await client.get("/api/stats")
        assert res.status_code == 200
        stats = res.json()
        print(f"[PASS] 2. Stats API -> Tracked: {stats.get('total_products_tracked')}, Active Deals: {stats.get('active_deals_count')}")

        # Check 3: Deals API
        res = await client.get("/api/deals?min_discount=50")
        assert res.status_code == 200
        data = res.json()
        total_deals = data.get("total", 0)
        print(f"[PASS] 3. Deals API -> Found {total_deals} qualified deals")

        # Check 4: History Endpoint
        if data.get("deals"):
            first_deal = data["deals"][0]
            prod_id = first_deal["id"]
            res = await client.get(f"/api/products/{prod_id}/history")
            assert res.status_code == 200
            history_pts = res.json()
            print(f"[PASS] 4. Price History API -> Product #{prod_id} has {len(history_pts)} historical data points")

    print("\n>>> ALL SYSTEM CHECKS PASSED: APP IS FULLY FUNCTIONAL AND READY TO USE! <<<")

if __name__ == "__main__":
    asyncio.run(run_checks())
