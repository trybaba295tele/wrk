# Deal Finder Pro — MRP Glitch & Heavy Discount Hunter

An automated e-commerce deal intelligence system that continuously tracks prices across **Amazon India**, **Flipkart**, and **Myntra**, detects **MRP errors** (pricing mistakes) and **heavy discounts (70%+ off)**, tracks historical price fluctuations in SQLite, alerts instantly via Telegram, and presents deals on a fast, modern dashboard.

---

## 🚀 Key Features

1. **Intelligent Deal & MRP Error Detection**:
   - **Heavy Discount Flag**: Detects genuine deals with >= 70% discount (configurable).
   - **MRP Error / Pricing Glitch**: Detects products whose current price is 80%+ lower than their own 30-day average price or experiencing extreme markdown anomalies.
   - **Quality Filters**: Disqualifies out-of-stock items, sellers with low ratings (< 3.0★), and products with fewer than 5 reviews.
   - **Confidence Scoring (0-100)**: Evaluates discount depth, price delta from 30-day moving average, seller reputation, and review volume with human-readable rationale.

2. **Resilient Multi-Source Scraping**:
   - Unified `BaseScraper` interface across **Amazon.in**, **Flipkart**, and **Myntra**.
   - Dual-mode scraping: fast async `httpx` + `BeautifulSoup` with automatic headless **Playwright** fallback for dynamic JS-rendered pages.
   - Anti-bot measures: rotating User-Agents, randomized delays (2–5s), exponential backoff retries, and graceful captcha detection.
   - Scrapes category, deal, and clearance pages (not just static product URLs).

3. **Real-time Web Dashboard**:
   - Built with **FastAPI**, **Tailwind CSS**, and **Chart.js**.
   - Live filters: By site (Amazon, Flipkart, Myntra), Deal Type, Min Discount, Price Range, and Sort Order.
   - Interactive **30-Day Price History Line Chart** modal per item.
   - Auto-injected **affiliate tracking tags** for direct monetization.
   - 30-second live auto-refresh with manual "Scan Deals Now" trigger.

4. **Automated Scheduling & Alerts**:
   - Powered by **APScheduler** running asynchronously every 30 minutes.
   - Instant **Telegram Bot Notifications** with Markdown formatting and alert deduplication to prevent alert fatigue.

---

## 📁 Project Folder Structure

```
deal_finder/
├── app/
│   ├── scrapers/
│   │   ├── __init__.py         # Scraper module exports
│   │   ├── base.py             # BaseScraper interface & Playwright fallback
│   │   ├── utils.py            # User agents, delays, price cleaning & retry logic
│   │   ├── amazon.py           # Amazon India scraper & PA-API hooks
│   │   ├── flipkart.py         # Flipkart scraper & Affiliate hooks
│   │   └── myntra.py           # Myntra scraper (JSON / SPA parser)
│   ├── static/
│   │   ├── index.html          # Tailwind CSS dashboard with Chart.js
│   │   ├── css/
│   │   │   └── style.css       # Custom animations, scrollbars, glow effects
│   │   └── js/
│   │       └── app.js          # Dynamic UI, filtering, Chart.js & API sync
│   ├── __init__.py
│   ├── config.py               # YAML & environment variable loader
│   ├── database.py             # Async SQLite SQLAlchemy engine & sessionmaker
│   ├── models.py               # Product, PriceHistory, and DealAlert models
│   ├── schemas.py              # Pydantic DTOs for scrapers and REST API
│   ├── engine.py               # Deal evaluation, scoring & upsert engine
│   ├── notifier.py             # Telegram alerting service with deduplication
│   ├── scheduler.py            # APScheduler background tasks
│   └── main.py                 # FastAPI application, REST endpoints & seeding
├── .env.example                # Sample environment secrets
├── .env                        # Local environment file
├── config.yaml                 # Core configuration (thresholds, URLs, affiliate tags)
├── requirements.txt            # Python dependencies
├── run.py                      # Uvicorn entrypoint script
└── README.md
```

---

## 🛠️ Step-by-Step Setup & Run Instructions

### 1. Requirements
- Python 3.11+
- pip (Python package manager)

### 2. Create and Activate a Virtual Environment
```bash
cd deal_finder
python -m venv venv

# On Windows:
venv\Scripts\activate

# On Linux/macOS:
source venv/bin/activate
```

### 3. Install Dependencies & Playwright Browsers
```bash
pip install -r requirements.txt
playwright install chromium
```

### 4. Configure Environment & Settings
Check `config.yaml` to adjust thresholds, scrape categories, or affiliate tags.

To enable Telegram alerts:
1. Open `.env` and set your credentials:
   ```env
   TELEGRAM_BOT_TOKEN="123456789:ABCdefGhIJKlmNoPQRstuVWXyz"
   TELEGRAM_CHAT_ID="987654321"
   TELEGRAM_ALERTS_ENABLED=true
   ```
2. (Optional) Provide your official Amazon or Flipkart affiliate IDs in `config.yaml` or `.env`.

### 5. Launch the Web Application
```bash
python run.py
```
Open your browser and navigate to:
**`http://localhost:8000`**

On initial startup, the database (`deals.db`) is automatically initialized, sample verified deals are seeded so you can immediately inspect the dashboard and price charts, and the background deal discovery scheduler begins execution.

---

## 🧭 How to Add a New Site (e.g. Ajio, Tata CLiQ, Croma)

Adding a new platform takes just 4 simple steps:

### Step 1: Create a New Scraper in `app/scrapers/<site>.py`
Subclass `BaseScraper` and implement `scrape_category` and `fetch_product`:

```python
# app/scrapers/ajio.py
from app.scrapers.base import BaseScraper
from app.schemas import ScrapedProductItem

class AjioScraper(BaseScraper):
    site_id = "ajio"
    name = "Ajio India"

    async def scrape_category(self, url: str, category_name: str) -> list[ScrapedProductItem]:
        # Fetch with fetch_html_with_retry or self.render_with_playwright
        # Parse products and return list of ScrapedProductItem
        ...

    async def fetch_product(self, url: str) -> ScrapedProductItem | None:
        ...
```

### Step 2: Export in `app/scrapers/__init__.py`
```python
from .ajio import AjioScraper
__all__ = ["BaseScraper", "AmazonScraper", "FlipkartScraper", "MyntraScraper", "AjioScraper"]
```

### Step 3: Register in `app/scheduler.py`
In `DealFinderScheduler.__init__`:
```python
self.scrapers = {
    "amazon": AmazonScraper(),
    "flipkart": FlipkartScraper(),
    "myntra": MyntraScraper(),
    "ajio": AjioScraper(),
}
```

### Step 4: Add Category URLs & Affiliate Tag in `config.yaml`
```yaml
affiliate:
  ajio_tag: "myajiotag"

categories:
  ajio:
    - name: "Ajio 70%+ Sale"
      url: "https://www.ajio.com/s/70-to-100-percent-off"
      category: "Fashion"
```
That's it! The scheduler and UI will automatically discover and monitor the new store.
